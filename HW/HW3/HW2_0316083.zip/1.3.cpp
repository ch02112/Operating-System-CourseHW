
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

using namespace std;


pthread_spinlock_t lock;

class Counter
{
    int value;
    public:
        Counter(){value=0;}

        void Increment()
        {value++;}

        void Print()
        {cout<<value;}

};
Counter x;

void*ThreadRunner(void*)
{
    int k;
    pthread_spin_lock(&lock);
    for(k=0;k<100000000;k++)
    x.Increment();
    pthread_spin_unlock(&lock);
}

int main()
{

    pthread_spin_init(&lock, 0);
    pthread_t tid[3];
    int i;
    for(i=0;i<3;i++)
        pthread_create(&tid[i],NULL,ThreadRunner,0);

    for(i=0;i<3;i++)
        pthread_join(tid[i],NULL);

    x.Print();

    return 0;
}
