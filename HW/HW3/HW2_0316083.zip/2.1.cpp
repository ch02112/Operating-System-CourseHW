
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <pthread.h>

using namespace std;
int number_of_points_in_circle=0;
int  total_number_of_points=0;

int number_points_in_circle[1000];



struct thread_data
{
    int n_of_thread;
    int allPoint;
};

struct thread_data thread_data_array[1000];

void *randRunner(void *threadarg);


int main(int argc, char *argv[]) {

    srand(time(NULL));
    int total_number_of_points=atoi(argv[1]);
    pthread_t tid[1000];
    void *re[1000];
    int k;
    int sum=0;
    for(k=0;k<1000;k++)
       {
            thread_data_array[k].n_of_thread=k;
            thread_data_array[k].allPoint=total_number_of_points;
            pthread_create(&tid[k],NULL,randRunner,(void*) &thread_data_array[k]);
       }

    for(k=0;k<1000;k++)
        pthread_join(tid[k],NULL);

    for(k=0;k<1000;k++)
        number_of_points_in_circle=number_of_points_in_circle+number_points_in_circle[k];

    printf("pi estimate = %f\n", (double) 4 *number_of_points_in_circle/ total_number_of_points);

    return 0;
}

void *randRunner(void *threadarg){

    struct thread_data *my_data;
    my_data=(thread_data *)threadarg;

    int k=my_data->n_of_thread;
    int total_point=my_data->allPoint;

    for(int i = 1; i < (total_point/1000); i++) {
        long double x = (long double) rand() / RAND_MAX;
        long double y = (long double) rand() / RAND_MAX;
        if((x * x + y * y) < 1 ) {
            number_points_in_circle[k]++;
            }
    }
    return (void *)number_of_points_in_circle;
}
