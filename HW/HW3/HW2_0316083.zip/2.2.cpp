
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <pthread.h>


int number_of_points_in_circle, total_number_of_points;

pthread_mutex_t counter_mutex = PTHREAD_MUTEX_INITIALIZER;

void *randRunner(void *p);


int main(int argc, char *argv[]) {

    srand(time(NULL));
    long p=atoi(argv[1]);
    pthread_t tid[1000];
    int k;
    int sum=0;
    for(k=0;k<1000;k++)
        pthread_create(&tid[k],NULL,randRunner,(void*) p);

    for(k=0;k<1000;k++)
        pthread_join(tid[k],NULL);


    printf("pi estimate = %f\n", (double) 4 *number_of_points_in_circle/ total_number_of_points);

    return 0;
}

void *randRunner(void *p){
    int i;
    long point;
    point=(long) p;
    pthread_mutex_lock(&counter_mutex);
    for(i = 1; i < (point/1000); i++) {
        long double x = (long double) rand() / RAND_MAX;
        long double y = (long double) rand() / RAND_MAX;
        total_number_of_points++;
        if((x * x + y * y) < 1) {
            number_of_points_in_circle ++;
            }
    }
    pthread_mutex_unlock(&counter_mutex);
}
