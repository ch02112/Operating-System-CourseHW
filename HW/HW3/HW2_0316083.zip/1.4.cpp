
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <pthread.h>

using namespace std;

int lock=0;

class Counter
{
    int value;
    public:
        Counter(){value=0;}

        void Increment()
        {value++;}

        void Print()
        {cout<<value;}

};
Counter x;


void homemade_spin_lock(int *spinlock_addr) {

  asm(
    "spin_lock: \n\t"
    "xorl %%ecx, %%ecx \n\t"
    "incl %%ecx \n\t"
    "spin_lock_retry: \n\t"
    "xorl %%eax, %%eax \n\t"
    "lock; cmpxchgl %%ecx, (%0) \n\t"
    "jnz spin_lock_retry \n\t"
    : : "r" (spinlock_addr) : "ecx", "eax" );
}

void homemade_spin_unlock(int *spinlock_addr) {

  asm(
    "spin_unlock: \n\t"
    "movl $0, (%0) \n\t"
    : : "r" (spinlock_addr) : );
}


void*ThreadRunner(void*)
{
    int k;
    homemade_spin_lock(&lock);
    for(k=0;k<100000000;k++)
    x.Increment();
    homemade_spin_unlock(&lock);
}

int main()
{


    pthread_t tid[3];
    int i;
    for(i=0;i<3;i++)
        pthread_create(&tid[i],NULL,ThreadRunner,0);

    for(i=0;i<3;i++)
        pthread_join(tid[i],NULL);

    x.Print();

    return 0;
}
