#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>


int N_ncar=0;
int N_pass=0;
bool N_succ=1;
int N_get=0;
bool N_stop=0;


int E_ncar=0;
int E_pass=0;
bool E_succ=1;
int E_get=0;
bool E_stop=0;

int S_ncar=0;
int S_pass=0;
bool S_succ=1;
int S_get=0;
bool S_stop=0;

int W_ncar=0;
int W_pass=0;
bool W_succ=1;
int W_get=0;
bool W_stop=0;


long long clk;
bool wait= 1;
bool dead_lock = 0;

pthread_mutex_t lock0;
pthread_mutex_t lock1;
pthread_mutex_t lock2;
pthread_mutex_t lock3;
long long state[5] = {1,0,0,0,0};

void* tANDd(void*);
void* N(void* );
void* E(void* );
void* S(void* );
void* W(void* );

int main(int argc, char*argv[])
{


    pthread_t tid[4];
    pthread_t time;

    N_ncar = atoi(argv[1]);
    E_ncar = atoi(argv[2]);
    S_ncar = atoi(argv[3]);
    W_ncar = atoi(argv[4]);

    if(N_ncar > 0 || E_ncar > 0 || S_ncar > 0 || W_ncar> 0)
    {
        pthread_create(&time, NULL, tANDd, NULL);
        pthread_create(&tid[0], NULL, N, 0);
        pthread_create(&tid[1], NULL, E, 0);
        pthread_create(&tid[2], NULL, S, 0);
        pthread_create(&tid[3], NULL, W, 0);

        for (int i = 0; i < 4; i++)
            pthread_join(tid[i], NULL);
        pthread_join(time, NULL);
    }
    return 0;
}
void* tANDd(void*)
{
    clk= 1;
    int i;
    while(wait)
    {
        while(state[0]>state[1] ||state[0]>state[2] ||state[0]>state[3] ||state[0]>state[4])
        {}
        clk++;
        if(N_ncar == 0 && E_ncar == 0 && S_ncar == 0 && W_ncar == 0)
            wait = 0;
        if(N_succ == 0 && E_succ == 0 && S_succ == 0 && W_succ == 0)
        {
            dead_lock = 1;
            printf("DEADLOCK HAPPENS at %lld\n", clk- 1);
        }
        state[0]++;

    }
}

void* N(void* )
{

    while(wait)
    {
        if(N_ncar > 0 && dead_lock == 0 && N_stop == 0)
        {
            if(N_get == 0)
            {
                if(pthread_mutex_trylock(&lock0) == 0)
                {
                    N_succ = 1;
                   N_get++;
                }
                else
                    N_succ = 0;
            }
            else if(N_get == 1)
            {
                if(pthread_mutex_trylock(&lock2) == 0)
                {
                   N_succ = 1;
                    N_get++;
                }
                else
                    N_succ = 0;
            }
            else if(N_get == 2)
            {
                N_succ = 1;
                N_get++;
                printf("N %d leaves at %lld\n", N_pass, clk);
            }
            else
            {
                N_ncar--;
                N_get = 0;
                N_succ = 1;
                N_pass++;
                pthread_mutex_unlock(&lock0);
                pthread_mutex_unlock(&lock2);
            }
        }
        else if(dead_lock == 1 && N_stop == 0)
        {

            N_stop = 1;
            N_succ = 1;
            dead_lock = 0;
           N_get = 0;
            pthread_mutex_unlock(&lock0);
        }
        else
        {
            N_stop = 0;
        }
        state[1]++;
        while(state[0] <= state[1])
        {}
    }
}

void* E(void* )
{

    while(wait)
    {
        if(E_ncar > 0 && dead_lock == 0 && E_stop == 0)
        {
            if(E_get == 0)
            {
                if(pthread_mutex_trylock(&lock1) == 0)
                {
                    E_succ = 1;
                    E_get++;
                }
                else
                    E_succ = 0;
            }
            else if(E_get == 1)
            {
                if(pthread_mutex_trylock(&lock0) == 0)
                {
                    E_succ = 1;
                    E_get++;
                }
                else
                    E_succ = 0;
            }
            else if(E_get == 2)
            {
                E_succ = 1;
                E_get++;
                printf("E %d leaves at %lld\n", E_pass, clk);
            }
            else
            {
                E_ncar--;
                E_get = 0;
                E_succ = 1;
                E_pass++;
                pthread_mutex_unlock(&lock1);
                pthread_mutex_unlock(&lock0);
            }
        }
        state[2]++;
        while(state[0] <= state[2])
        {}
    }
}

void* S(void* )
{

    while(wait)
    {
        if(S_ncar> 0 && dead_lock == 0 && S_stop == 0)
        {
            if(S_get == 0)
            {
                if(pthread_mutex_trylock(&lock3) == 0)
                {
                    S_succ = 1;
                    S_get++;
                }
                else
                   S_succ = 0;
            }
            else if(S_get == 1)
            {
                if(pthread_mutex_trylock(&lock1) == 0)
                {
                    S_succ= 1;
                    S_get++;
                }
                else
                    S_succ = 0;
            }
            else if(S_get== 2)
            {
                S_succ = 1;
                S_get++;
                printf("S %d leaves at %lld\n", S_pass, clk);
            }
            else
            {
                S_ncar--;
                S_get = 0;
                S_succ = 1;
                S_pass++;
                pthread_mutex_unlock(&lock3);
                pthread_mutex_unlock(&lock1);
            }
        }
        state[3]++;
        while(state[0] <= state[3])
        {}
    }
}

void* W(void* )
{
    while(wait)
    {
        if(W_ncar > 0 && dead_lock == 0 && W_stop == 0)
        {
            if(W_get == 0)
            {
                if(pthread_mutex_trylock(&lock2) == 0)
                {
                    W_succ= 1;
                    W_get++;
                }
                else
                   W_succ = 0;
            }
            else if(W_get == 1)
            {
                if(pthread_mutex_trylock(&lock3) == 0)
                {
                    W_succ = 1;
                    W_get++;
                }
                else
                    W_succ = 0;
            }
            else if(W_get == 2)
            {
                W_succ = 1;
                W_get++;
                printf("W %d leaves at %lld\n", W_pass, clk);
            }
            else
            {
                W_ncar--;
                W_get = 0;
                W_succ = 1;
                W_pass++;
                pthread_mutex_unlock(&lock2);
                pthread_mutex_unlock(&lock3);
            }
        }
        state[4]++;
        while(state[0] <= state[4])
        {}
    }
}
